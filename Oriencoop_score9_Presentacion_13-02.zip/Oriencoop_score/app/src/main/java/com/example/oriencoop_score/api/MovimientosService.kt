package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.CuentaCapResponse
import com.example.oriencoop_score.model.MovimientosResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface MovimientosService {
    @POST("/movimientos")
    suspend fun getMovimientos(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<MovimientosResponse>
}