package com.example.oriencoop_score.view.mis_productos.credito_cuotas

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.oriencoop_score.R
import com.example.oriencoop_score.model.CreditoCuota
import com.example.oriencoop_score.ui.theme.AppTheme
import com.example.oriencoop_score.view.mis_productos.cuenta_ahorro.DetailRow


@OptIn(ExperimentalMaterial3Api::class)

@Composable
fun CreditoCuotaItem(cuenta: CreditoCuota, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) AppTheme.colors.azul else Color.White
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = cuenta.NROCUENTA.toString(),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = if (isSelected) Color.White else Color.Black
            )
            val dropdownIcon: Painter = if (isSelected) {
                painterResource(id = R.drawable.chevronup) // Your "up" image
            } else {
                painterResource(id = R.drawable.chevrondown) // Your "down" image
            }
            Image(
                painter = dropdownIcon,
                contentDescription = if (isSelected) "Collapse" else "Expand",
                modifier = Modifier.size(24.dp), // Adjust size as needed
                contentScale = ContentScale.Fit // or ContentScale.Crop, etc.
            )
        }
    }
}

@Composable
fun DetallesCreditoCuotas(cuenta: CreditoCuota) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp), // padding horizontal para alinear con el item de arriba
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DetailRow(label = "Tipo:", value = cuenta.TIPOCUENTA)
            DetailRow(label = "Número Cuotas:", value = "${cuenta.NUMEROCUOTAS}")
            DetailRow(label = "Monto Crédito:", value = cuenta.MONTOCREDITO)
            DetailRow(label = "Valor Cuota:", value = cuenta.VALORCUOTA)
            DetailRow(label = "Prox Movimiento:", value = cuenta.PROXVENCIMIENTO)
        }
    }
}


/*
@Composable
fun DetallesCreditoCuotas(
    nroCuenta: String,
    tipoCuenta: String,
    nroCuotas: String,
    montoCredito: String,
    valorCuota: String,
    fechaVencimiento: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppTheme.colors.azul)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Número de cuenta
                Text(
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    text = nroCuenta,
                    style = AppTheme.typography.normal,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Icon(
                    painter = painterResource(id = R.drawable.info),
                    contentDescription = "Info",
                    tint = AppTheme.colors.amarillo,
                    modifier = Modifier
                        .clickable {}
                        .size(24.dp)
                )
            }


            Spacer(modifier = Modifier.height(8.dp))

            // Saldo
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Tipo Cuenta",
                    color = Color.White,
                    style = AppTheme.typography.normal,
                    modifier = Modifier.weight(1f),

                )
                Text(
                    text = tipoCuenta,
                    color = Color.White,
                    style = AppTheme.typography.normal,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Right
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Número de Cuotas",
                    color = Color.White,
                    style = AppTheme.typography.normal

                )
                Text(
                    text = nroCuotas,
                    color = Color.White,
                    style = AppTheme.typography.normal

                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Monto Crédito",
                    color = Color.White,
                    style = AppTheme.typography.normal
                )
                Text(
                    text = montoCredito,
                    color = Color.White,
                    style = AppTheme.typography.normal
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Valor Cuota",
                    color = Color.White,
                    style = AppTheme.typography.normal
                )
                Text(
                    text = valorCuota,
                    color = Color.White,
                    style = AppTheme.typography.normal
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Próximo Vencimiento",
                    color = Color.White,
                    style = AppTheme.typography.normal
                )
                Text(
                    text = fechaVencimiento,
                    color = Color.White,
                    style = AppTheme.typography.normal
                )
            }
        }
    }
}
*/