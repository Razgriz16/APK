package com.example.oriencoop_score.repository

import android.util.Log
import com.example.oriencoop_score.Result
import com.example.oriencoop_score.api.LoginManageApi
import com.example.oriencoop_score.model.MovimientosLccResponse
import com.example.oriencoop_score.model.RutRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MovimientosLccRepository {
    private val movimientosLccService = LoginManageApi.movimientosLccService

    suspend fun getMovimientosLcc(token: String, rut: String): Result<MovimientosLccResponse> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("MovimientoLccRepository", "llamando función getMovimientosAhorro")
                val response = movimientosLccService.getMovimientosLcc(token, RutRequest(rut))
                if (response.isSuccessful) {
                    Log.d("MovimientoLccRepository", "Llamada exitosa. BODY "+response.body())
                    Result.Success(response.body()!!)
                }
                else {
                    Log.e("MovimientoLccRepository", "Llamada fallida. Error: ${response.code()} ${response.message()}")
                    Result.Error(Exception("Error: ${response.code()} ${response.message()}"))
                }
            } catch (e: Exception) {
                Log.e("MovimientoLccRepository", "Exception Api call. Error: ${e.message}")
                Result.Error(e)
            }
        }
    }
}