package com.example.oriencoop_score.view.mis_productos.cuenta_cap


import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.oriencoop_score.R
import com.example.oriencoop_score.ui.theme.AppTheme


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Detalles(
    accountNumber: String,
    balance: String,
    openingDate: String,
    accountType: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        // Número de cuenta en rectángulo ovalado
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = AppTheme.colors.azul,
                    shape = RoundedCornerShape(8.dp) // Forma ovalada
                )
                .padding(16.dp),
            contentAlignment = Alignment.Center // Texto centrado
        ) {
            Text(
                text = accountNumber,
                style = AppTheme.typography.normal,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp), // padding horizontal para alinear con el item de arriba
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(8.dp)
        )
         {
            Column(modifier = Modifier.padding(16.dp)) {

                // Saldo
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Saldo Contble",
                        color = Color.Black, // Color de texto negro
                        style = AppTheme.typography.normal
                    )
                    Text(
                        text = balance,
                        color = Color.Black, // Color de texto negro
                        style = AppTheme.typography.normal,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Fecha Apertura",
                        color = Color.Black, // Color de texto negro
                        style = AppTheme.typography.normal

                    )
                    Text(
                        text = openingDate,
                        color = Color.Black, // Color de texto negro
                        style = AppTheme.typography.normal

                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Tipo",
                        color = Color.Black, // Color de texto negro
                        style = AppTheme.typography.normal
                    )
                    Text(
                        text = accountType,
                        color = Color.Black, // Color de texto negro
                        style = AppTheme.typography.normal
                    )
                }
            }
        }
    }
}