package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.LccResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface LccService {
    @POST("/lcc")
    suspend fun getLcc(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<LccResponse>
}