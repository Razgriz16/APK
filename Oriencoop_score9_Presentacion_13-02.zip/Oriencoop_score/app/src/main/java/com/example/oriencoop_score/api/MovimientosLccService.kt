package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.MovimientosLccResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface MovimientosLccService {
    @POST("/movimientos_lcc")
    suspend fun getMovimientosLcc(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<MovimientosLccResponse>
}
