package com.example.oriencoop_score.view_model


import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oriencoop_score.LoginState
import com.example.oriencoop_score.repository.LoginRepository
import kotlinx.coroutines.launch
import com.example.oriencoop_score.Result
import com.example.oriencoop_score.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LoginViewModel() : ViewModel() {
    private val loginRepository = LoginRepository()

    // Estado del formulario (username y password)
    private val _username = MutableStateFlow("")
    private val _password = MutableStateFlow("")

    // Estado global del login (éxito, error, carga)
    private val _loginState = MutableStateFlow<LoginState>(LoginState.Idle)

    // Exponer estados para UI
    val username: StateFlow<String> = _username
    val password: StateFlow<String> = _password
    val loginState: StateFlow<LoginState> = _loginState

    // Token obtenido (público pero solo lectura)
    private val _token = MutableStateFlow("")
    val token: StateFlow<String> = _token



    // Actualizar campos del formulario
    fun updateUsername(newUsername: String) {
        _username.value = newUsername
    }

    fun updatePassword(newPassword: String) {
        _password.value = newPassword
    }
    fun performLogin(username: String, password: String) {
        viewModelScope.launch {
            try {
                /*
                3224212
                28D3A86A1E9401BFD67266D7189936A6638DA54E
                5980334
                CFC253C1E446785B61AB66ACA3D2A36C332463C2
                20069723
                DF60F113C0F65E52B746558911CC0059E083BE09
                14345673
                13793E4CEB511A3F9BD9BC5AEC29851697CF7E3C
                */
                // Login oculto
                Log.d("Login", "Antes de hacer el login entidad")
                val hiddenLoginResult = loginRepository.performHiddenLogin("admin", "securepassword")
                if (hiddenLoginResult is Result.Success) {
                    val token = hiddenLoginResult.data.token // Extract the token field
                    Log.d("Login", "Hidden login result: $hiddenLoginResult")
                    _token  .value = token // Guardar el token
                    println("login state view model(1)"+loginState)
                    // Step 2: Perform User Login with user-provided credentials and token
                    Log.d("Login", "Performing user login with token: $token")
                    val userLoginResult = loginRepository.performUserLogin(token, "11232873","DF58BEDDEA62A27CF59F08EF8DFAFD62850834B1", )
                    if (userLoginResult is Result.Success) {
                        _username.value = username
                        _password.value = password // Guardar el nombre de usuario
                        _loginState.value = LoginState.Success(userLoginResult.data)
                        SessionManager.saveSession(token, "11232873")
                        println("login state view model(2)"+loginState)
                    } else if (userLoginResult is Result.Error) {
                        _loginState.value = LoginState.Error(
                            userLoginResult.exception.message ?: "User login failed"
                        )
                    }
                } else if (hiddenLoginResult is Result.Error) {
                    _loginState.value = LoginState.Error(
                        hiddenLoginResult.exception.message ?: "Hidden login failed"
                    )
                }
                println("login state view model(3)"+loginState)
            } catch (e: Exception) {
                _loginState.value = LoginState.Error(e.message ?: "An unexpected error occurred")
            }

        }
    }
}


/* //VERSION ANTIGUA VIEW MODEL QUE PERMITE LOGEAR CON MAS DE 6 CARACTERES EN LA CONTRASEÑA
    //private val repository = UserRepository()
    private val _rut = MutableLiveData<String>()
    val rut: LiveData<String> = _rut

    private val _password = MutableLiveData<String>()
    val password: LiveData<String> = _password

    private val _loginEnable = MutableLiveData<Boolean>()
    val loginEnable: LiveData<Boolean> = _loginEnable

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun onLoginChanged(rut: String, password: String) {
        _rut.value = rut
        _password.value = password
        //_loginEnable.value = isValidPassword(password) && isValidRut(rut)
    }

    private fun isValidPassword(password: String): Boolean = password.length >= 6

    private fun isValidRut(rut: String): Boolean {
        return rut.isNotEmpty()
    }

    fun onLoginSelected() {/*
        viewModelScope.launch {
            _isLoading.value = true

            val rut = _rut.value ?: ""
            val password = _password.value ?: ""
            val loginRequest = UserResponse(rut, password)

            val result = repository.validateLogin(loginRequest) // Fully qualified
            _loginResult.value = result

            _isLoading.value = false
        }*/
    }*/