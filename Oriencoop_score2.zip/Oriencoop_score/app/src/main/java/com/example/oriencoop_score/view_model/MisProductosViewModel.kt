package com.example.oriencoop_score.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oriencoop_score.model.MisProductosResponse
import com.example.oriencoop_score.repository.MisProductosRepository
import kotlinx.coroutines.launch
import com.example.oriencoop_score.Result

class MisProductosViewModel() : ViewModel() {
    private val misProductosRepository = MisProductosRepository()
    private val _productosState = MutableLiveData<Result<MisProductosResponse>>()
    val productosState: LiveData<Result<MisProductosResponse>> get() = _productosState

    // Estado procesado para los botones
    private val _botonesState = MutableLiveData<Map<String, Boolean>>()
    val botonesState: LiveData<Map<String, Boolean>> get() = _botonesState

    fun obtenerProductos(token: String, rut: String) {
        viewModelScope.launch {
            val result = misProductosRepository.getProductos(token, rut)
            _productosState.value = result

            // Procesar el resultado para determinar la visibilidad de los botones
            if (result is Result.Success) {
                val productos = result.data
                val botonesVisibles = mapOf(
                    "AHORRO" to (productos.AHORRO != 0),
                    "CREDITO" to (productos.CREDITO != 0),
                    "CSOCIAL" to (productos.CSOCIAL != 0),
                    "DEPOSTO" to (productos.DEPOSTO != 0),
                    "LCC" to (productos.LCC != 0),
                    "LCR" to (productos.LCR != 0)
                )
                _botonesState.value = botonesVisibles
            }
        }
    }
}