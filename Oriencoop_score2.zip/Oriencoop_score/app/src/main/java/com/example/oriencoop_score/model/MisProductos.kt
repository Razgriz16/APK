package com.example.oriencoop_score.model


data class MisProductosResponse(
    val AHORRO: Int,
    val CREDITO: Int,
    val CSOCIAL: Int,
    val DEPOSTO: Int,
    val LCC: Int,
    val LCR: Int
)