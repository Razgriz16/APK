package com.example.oriencoop_score.view
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.oriencoop_score.R
import kotlinx.coroutines.launch


//*****Pantalla Principal*****
@Composable
fun PantallaPrincipal(
    navController: NavController
) {
    val drawerState = rememberDrawerState(androidx.compose.material3.DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(onCloseDrawer = { coroutineScope.launch { drawerState.close() } }, navController)
        },
        gesturesEnabled = true, // Enable swipe gestures to open/close drawer

        content = {
            Scaffold(
                topBar = {
                    HeaderRow(
                        onMenuClick = {
                            coroutineScope.launch {
                                drawerState.open()
                            }
                        },
                    )
                },
                bottomBar = {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 16.dp)

                    )
                    { BottomBar(navController) } // Assuming you have a BottomBar composable
                },
                content = { padding -> // padding values are provided by Scaffold to avoid overlapping with topBar and bottomBar
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White)
                            .padding(padding), // Apply padding to the Column content
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {

                        // Saldo
                        Saldo()

                        Image(
                            painter = painterResource(id = R.drawable.banner),
                            contentDescription = "Banner",
                            modifier = Modifier
                                .padding(50.dp)
                        )

                        MindicatorTest()

                        Spacer(modifier = Modifier.weight(1f))

                    }
                }
            )
        }
    )
}
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PantallaPrincipalPreview() {
    val navController = rememberNavController() // Create a dummy NavController for preview
    PantallaPrincipal(navController)
}
