package com.example.oriencoop_score.repository

import android.media.AudioRecord.OnRecordPositionUpdateListener
import android.util.Log
import com.example.oriencoop_score.Result
import com.example.oriencoop_score.api.LoginManageApi
import com.example.oriencoop_score.model.CuentaCapResponse
import com.example.oriencoop_score.model.RutRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class CuentaCapRepository {
    val cuentaCapService = LoginManageApi.cuentaCapService
    suspend fun getCuentaCap(token: String, rut: String): Result<CuentaCapResponse> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("CuentaCapRepository", "llamando función getCuentaCap")
                val response = cuentaCapService.getCuentaCap(token, rut)
                if (response.isSuccessful) {
                    Log.d("CuentaCapRepository", "llamada api exitosa. BODY: ${response.body()}")
                    response.body()?.let{Result.Success(it)}?: Result.Error(Exception("Respuesta vacía"))
                } else {
                    Log.e("CuentaCapRepository", "Llamada fallida. Error: ${response.code()} ${response.message()}")
                    Result.Error(Exception("Error: ${response.code()} ${response.message()}"))
                }
            } catch (e: Exception) {
                Log.e("CuentaCapRepository", "Exception Api call. Error: ${e.message}")
                Result.Error(e)
            }
        }
    }

}
