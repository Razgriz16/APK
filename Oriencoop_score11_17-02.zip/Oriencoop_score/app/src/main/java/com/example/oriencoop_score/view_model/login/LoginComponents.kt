package com.example.oriencoop_score.view_model.login

import java.nio.charset.Charset
import java.security.MessageDigest
import java.nio.charset.StandardCharsets
import java.security.NoSuchAlgorithmException

fun generarHash(text: String): String? {
    return try {
        val md = MessageDigest.getInstance("SHA-1")
        val sha1hash = md.digest(text.toByteArray(Charset.forName("ISO-8859-1")))

        // Convertir a hexadecimal (implementación en Kotlin)
        sha1hash.joinToString("") { String.format("%02x", it) } // Más conciso
    } catch (ex: NoSuchAlgorithmException) {
        // Manejo de excepción (aquí se imprime a la consola, pero se puede usar un logger)
        println("Error: Algoritmo SHA-1 no encontrado.")
        null
    }
}

fun main() {
    val rut = 21186098-7
    val clave = "Forest28"
    val hash = generarHash(clave+rut)
    println("Hash SHA-1: $hash")
}


private fun bytesToHex(data: ByteArray): String {
    val buf = StringBuilder()
    for (byte in data) {
        var halfbyte = (byte.toInt() ushr 4) and 0x0F // ushr para desplazamiento sin signo
        var two_halfs = 0
        do {
            buf.append(if (halfbyte in 0..9) {
                '0' + halfbyte
            } else {
                'a' + (halfbyte - 10)
            })
            halfbyte = byte.toInt() and 0x0F
        } while (two_halfs++ < 1)
    }
    return buf.toString()
}