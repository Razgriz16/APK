package com.example.oriencoop_score.repository

import android.util.Log
import com.example.oriencoop_score.Result
import com.example.oriencoop_score.api.LoginManageApi
import com.example.oriencoop_score.model.MovimientosCreditosResponse
import com.example.oriencoop_score.model.RutRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MovimientosCreditosRepository {
    private val movimientosCreditosService = LoginManageApi.movimientosCreditosService

    suspend fun getMovimientosCreditos(token: String, rut: String): Result<MovimientosCreditosResponse> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("MovimientosCreditosRepository", "llamando función getMovimientosAhorro")
                val response = movimientosCreditosService.getMovimientosCreditos(token, rut)
                if (response.isSuccessful) {
                    Log.d("MovimientosCreditosRepository", "Llamada exitosa. BODY "+response.body())
                    Result.Success(response.body()!!)
                }
                else {
                    Log.e("MovimientosCreditosRepository", "Llamada fallida. Error: ${response.code()} ${response.message()}")
                    Result.Error(Exception("Error: ${response.code()} ${response.message()}"))
                }
            } catch (e: Exception) {
                Log.e("MovimientosCreditosRepository", "Exception Api call. Error: ${e.message}")
                Result.Error(e)
            }
        }
    }
}