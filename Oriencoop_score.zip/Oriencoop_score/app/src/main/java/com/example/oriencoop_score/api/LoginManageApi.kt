package com.example.oriencoop_score.api

import com.example.oriencoop_score.repository.LoginRepository
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object LoginManageApi {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        // Enable retrying on connection failures (helps mitigate transient network issues)
        .retryOnConnectionFailure(true)
        // Add an interceptor to force the connection to close after the request is completed.
        .addInterceptor { chain ->
            val originalRequest = chain.request()
            val requestWithClose = originalRequest.newBuilder()
                //.header("Connection", "close")
                .header("Content-Type", "application/json")
                .build()
            chain.proceed(requestWithClose)
        }
        .build()

    val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("http://192.168.120.8:5000/")
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val loginService: LoginService = retrofit.create(LoginService::class.java)
}

