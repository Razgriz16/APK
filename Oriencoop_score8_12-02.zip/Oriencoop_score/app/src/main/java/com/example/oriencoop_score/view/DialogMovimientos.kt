package com.example.oriencoop_score.view

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.oriencoop_score.model.MovimientosAhorro
import com.example.oriencoop_score.view.mis_productos.cuenta_ahorro.DetailRow
import com.example.oriencoop_score.view_model.MovimientosAhorroViewModel

@Composable
fun <VM> DialogMovimientos(
    movimiento: MovimientosAhorro,
    viewModel: VM,
    onDismissRequest: () -> Unit,
    content: @Composable (movimiento: MovimientosAhorro, viewModel: VM) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text(text = "Detalle del Movimiento") },
        text = {
            // La lambda "content" te permite definir aquí el contenido del diálogo,
            // utilizando el movimiento seleccionado y el viewmodel inyectado.
            content(movimiento, viewModel)
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Cerrar")
            }
        }
    )
}
