package com.example.oriencoop_score.navigation

import MindicatorsViewModel
import com.example.oriencoop_score.view_model.LoginViewModel
import com.example.oriencoop_score.view.PantallaPrincipal
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.oriencoop_score.repository.LoginRepository
import com.example.oriencoop_score.repository.MindicatorsRepository
import com.example.oriencoop_score.view.Login
import com.example.oriencoop_score.view.MisProductos
import com.example.oriencoop_score.view.mis_productos.credito_cuotas.CreditoCuotas
import com.example.oriencoop_score.view.mis_productos.cuenta_ahorro.CuentaAhorro
import com.example.oriencoop_score.view.mis_productos.cuenta_cap.CuentaCap
import com.example.oriencoop_score.view_model.CreditoCuotasViewModel
import com.example.oriencoop_score.view_model.CuentaAhorroViewModel
import com.example.oriencoop_score.view_model.CuentaCapViewModel
import com.example.oriencoop_score.view_model.MisProductosViewModel
import com.example.oriencoop_score.view_model.MovimientosAhorroViewModel
import com.example.oriencoop_score.view_model.MovimientosCreditosViewModel
import com.example.oriencoop_score.view_model.MovimientosViewModel

@Composable
fun Navigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Pantalla.Login.route) {
        composable(route = Pantalla.Login.route) {
            Login(navController = navController, LoginViewModel(LoginRepository()))
        }

        composable(route = Pantalla.MisProductos.route) {
            val loginViewModel=LoginViewModel(LoginRepository())
            MisProductos(navController = navController, MisProductosViewModel())
        }
        composable(route = Pantalla.PantallaPrincipal.route) {
            PantallaPrincipal(navController = navController, MindicatorsViewModel(MindicatorsRepository()), CuentaCapViewModel())
        }

        composable(route = Pantalla.CuentaCap.route) {

            CuentaCap(navController = navController, CuentaCapViewModel(), MovimientosViewModel()) /*, viewModel = harryPotterViewModel*/
        }

        composable(route = Pantalla.CuentaAhorro.route) {
            CuentaAhorro(navController = navController, CuentaAhorroViewModel(), MovimientosAhorroViewModel() ) /*, viewModel = harryPotterViewModel*/
        }

        composable(route = Pantalla.CreditoCuotas.route) {
            CreditoCuotas(navController = navController, CreditoCuotasViewModel(), MovimientosCreditosViewModel()) /*, viewModel = harryPotterViewModel*/
        }

    }
}


