package com.example.oriencoop_score.view.mis_productos.credito_cuotas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.example.oriencoop_score.ui.theme.AppTheme
import com.example.oriencoop_score.view.BottomBar
import com.example.oriencoop_score.view_model.CreditoCuotasViewModel
import com.example.oriencoop_score.view_model.MovimientosCreditosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreditoCuotas(
    navController: NavController,
    creditoCuotasViewModel: CreditoCuotasViewModel,
    movimientosCreditosViewModel: MovimientosCreditosViewModel
) {
    val creditoCuotasData by creditoCuotasViewModel.creditoCuotasData.collectAsState()
    val isLoading by creditoCuotasViewModel.isLoading.collectAsState()
    val error by creditoCuotasViewModel.error.collectAsState()
    val cuentaSeleccionada by creditoCuotasViewModel.cuentaSeleccionada.collectAsState()

    // State to control the expanded Movimientos dialog
    var showAllMovimientosDialog by remember { mutableStateOf(false) }
    var selectedAccountForDialog by remember { mutableStateOf<Long?>(null) }


    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Crédito Cuotas", color = Color.Black, textAlign = TextAlign.Center, fontSize = AppTheme.typography.normal.fontSize) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = com.example.oriencoop_score.ui.theme.amarillo // Use your theme color
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .padding(bottom = 16.dp)
            )
            { BottomBar(navController) } // Assuming you have a BottomBar composable
        }
    ) { paddingValues ->
        when {
            isLoading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }

            error?.isNotEmpty() == true -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(text = error ?: "Error desconocido", color = Color.Red)
            }

            else -> {
                Column(
                    modifier = Modifier
                        .background(Color.White)
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    creditoCuotasData?.let { data ->
                        data.credito_cuotas.forEach { cuenta ->
                            val isSelected = cuentaSeleccionada?.NROCUENTA == cuenta.NROCUENTA
                            Column {
                                CreditoCuotaItem(cuenta, isSelected) {
                                    creditoCuotasViewModel.selectCuenta(cuenta)
                                }

                                if (isSelected) {
                                    DetallesCreditoCuotas(cuenta) // Assuming you have this Composable
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Movimientos",
                                            style = MaterialTheme.typography.titleLarge,
                                            textAlign = TextAlign.Center
                                        )
                                        IconButton(onClick = {
                                            selectedAccountForDialog = cuenta.NROCUENTA
                                            showAllMovimientosDialog = true
                                        }) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "Ver todos los movimientos",
                                                tint = AppTheme.colors.azul // Use your theme color
                                            )
                                        }
                                    }

                                    MovimientosCreditosScreen(
                                        movimientosCreditosViewModel,
                                        selectedAccount = cuenta.NROCUENTA
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialog for all movements
        if (showAllMovimientosDialog) {
            AllMovimientosDialog(
                movimientosCreditosViewModel = movimientosCreditosViewModel,
                selectedAccount = selectedAccountForDialog ?: 0, // Provide a default value
                onDismiss = { showAllMovimientosDialog = false }
            )
        }
    }
}

@Composable
fun AllMovimientosDialog(
    movimientosCreditosViewModel: MovimientosCreditosViewModel,
    selectedAccount: Long,
    onDismiss: () -> Unit
) {
    val movimientos by movimientosCreditosViewModel.movimientos.collectAsState()
    val isLoading by movimientosCreditosViewModel.isLoading.collectAsState()
    val error by movimientosCreditosViewModel.error.collectAsState()

    val filteredMovimientos = movimientos.filter { it.NROCUENTA == selectedAccount }

    Dialog(
        onDismissRequest = { onDismiss() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false // Important for full-screen dialog
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            )
            {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically

                ){
                    Text(
                        "Todos los Movimientos",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(start = 16.dp),
                        textAlign = TextAlign.Center
                    )
                    IconButton(onClick = {onDismiss()}){
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = com.example.oriencoop_score.ui.theme.amarillo // Use your theme color
                        )
                    }
                }

                HorizontalDivider()

                when {
                    isLoading -> {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }

                    error != null -> {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = error ?: "Error desconocido",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    else -> {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 0.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(0.dp)
                        ) {
                            items(filteredMovimientos) { movimiento ->
                                com.example.oriencoop_score.view.mis_productos.credito_cuotas.MovimientosCreditosItem(movimiento = movimiento)
                                HorizontalDivider(thickness = 1.dp, color = Color.LightGray)
                            }
                        }
                    }
                }
            }

        }
    }
}




