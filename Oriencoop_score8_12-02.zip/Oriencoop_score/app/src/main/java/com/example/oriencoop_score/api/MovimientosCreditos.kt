package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.CreditoRequest
import com.example.oriencoop_score.model.MovimientosCreditosResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface MovimientosCreditos {
    @POST("/movimientos_creditos")
    suspend fun getMovimientosCreditos(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<MovimientosCreditosResponse>
}