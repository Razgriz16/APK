package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.CreditoCuotasResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface CreditoCuotasService {
    @POST("/credito_cuotas")
    suspend fun getCreditoCuotas(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<CreditoCuotasResponse>
}