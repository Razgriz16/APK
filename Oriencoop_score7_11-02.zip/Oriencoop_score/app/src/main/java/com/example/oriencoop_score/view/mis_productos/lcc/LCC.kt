package com.example.oriencoop_score.view.mis_productos.lcc

import com.example.oriencoop_score.view.mis_productos.cuenta_cap.Detalles
import com.example.oriencoop_score.view.mis_productos.cuenta_cap.MovimientosList
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oriencoop_score.ui.theme.AppTheme
import com.example.oriencoop_score.view.BottomBar
import com.example.oriencoop_score.view_model.CuentaCapViewModel
import com.example.oriencoop_score.view_model.MovimientosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LCC(navController: NavController, cuentaCapViewModel: CuentaCapViewModel, movimientosViewModel: MovimientosViewModel) {
    val cuentaCapData by cuentaCapViewModel.cuentaCapData.observeAsState()
    val movimientos by movimientosViewModel.movimientos.collectAsState()
    val isLoading by movimientosViewModel.isLoading.collectAsState()
    val error by movimientosViewModel.error.collectAsState()


    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Cuenta capitalización",
                        color = Color.Black,
                        textAlign = TextAlign.Center,
                        fontSize = AppTheme.typography.normal.fontSize
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {navController.popBackStack()}) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = com.example.oriencoop_score.ui.theme.amarillo
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .padding(bottom = 16.dp)

            )
            { BottomBar(navController) }
        }

    ) { paddingValues ->
        Column(
            modifier = Modifier
                .background(Color.White)
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
            //.verticalScroll(rememberScrollState())

        ) {
            Detalles(
                accountNumber = "${cuentaCapData?.NROCUENTA}",
                balance = "$ ${cuentaCapData?.SALDOCONTABLE}",
                openingDate = "${cuentaCapData?.FECHAAPERTURA}",
                accountType = "${cuentaCapData?.TIPOCUENTA}"
            )

            Spacer(modifier = Modifier.height(24.dp))
            Column(modifier = Modifier.fillMaxSize()) {
                // Title (You might want this in a separate composable)
                Text(
                    text = "Últimos Movimientos",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )


                MovimientosList(movimientos = movimientos)
                Spacer(modifier = Modifier.height(16.dp))

                Icon(
                    imageVector = Icons.Filled.ArrowDropDown, // Replace with your PNG
                    contentDescription = "Dropdown",
                    tint = Color.Gray
                )
            }
        }
    }
}

