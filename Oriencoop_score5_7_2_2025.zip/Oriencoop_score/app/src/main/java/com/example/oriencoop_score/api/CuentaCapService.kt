package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.CuentaCapResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST


interface CuentaCapService {
    @POST("/cuenta_cap")
    suspend fun getCuentaCap(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<CuentaCapResponse>
}