package com.example.oriencoop_score.navigation

import MindicatorsViewModel
import com.example.oriencoop_score.view_model.LoginViewModel
import com.example.oriencoop_score.view.PantallaPrincipal
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.oriencoop_score.repository.LoginRepository
import com.example.oriencoop_score.repository.MindicatorsRepository
import com.example.oriencoop_score.view.Login
import com.example.oriencoop_score.view.MisProductos
import com.example.oriencoop_score.view.mis_productos.cuenta_cap.CuentaCap
import com.example.oriencoop_score.view_model.CuentaCapViewModel
import com.example.oriencoop_score.view_model.MisProductosViewModel
import kotlin.math.log

@Composable
fun Navigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Pantalla.Login.route) {
        composable(route = Pantalla.Login.route) {
            Login(navController = navController, LoginViewModel(LoginRepository()))
        }

        composable(route = Pantalla.MisProductos.route) {
            val loginViewModel=LoginViewModel(LoginRepository())
            MisProductos(navController = navController, MisProductosViewModel())
        }
        composable(route = Pantalla.PantallaPrincipal.route) {
            PantallaPrincipal(navController = navController, MindicatorsViewModel(MindicatorsRepository()), CuentaCapViewModel())
        }

        composable(route = Pantalla.CuentaCap.route) {
            /*val harryPotterViewModel: HarryPotterViewModel = viewModel()*/
            CuentaCap(navController = navController, onBackClick = { navController.popBackStack() }, CuentaCapViewModel()) /*, viewModel = harryPotterViewModel*/
        }

    }
}


