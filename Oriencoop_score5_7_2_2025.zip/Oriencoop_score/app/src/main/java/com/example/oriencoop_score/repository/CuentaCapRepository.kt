package com.example.oriencoop_score.repository

import android.media.AudioRecord.OnRecordPositionUpdateListener
import android.util.Log
import com.example.oriencoop_score.Result
import com.example.oriencoop_score.api.LoginManageApi
import com.example.oriencoop_score.model.CuentaCapResponse
import com.example.oriencoop_score.model.RutRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class CuentaCapRepository {
    val cuentaCapService = LoginManageApi.cuentaCapService
    suspend fun getCuentaCap(token: String, rut: String): Result<CuentaCapResponse> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("repository", "llamando función getCuentaCap")
                val response = cuentaCapService.getCuentaCap(token, RutRequest(rut))
                Log.d("repository", "BODY CUENTA CAP ANTES SUCCESS"+response.body())
                if (response.isSuccessful) {
                    Log.d("repository", "BODY CUENTA CAP"+response.body())
                    response.body()?.let{Result.Success(it)}?: Result.Error(Exception("Respuesta vacía"))
                } else {
                    Result.Error(Exception("Error: ${response.code()} ${response.message()}"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }

}
