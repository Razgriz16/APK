package com.example.oriencoop_score.view
import MindicatorsViewModel
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oriencoop_score.R
import com.example.oriencoop_score.navigation.Pantalla


//*****Pantalla Principal*****
@Composable
fun PantallaPrincipal(
    navController: NavController,
    mindicatorsViewModel: MindicatorsViewModel
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        HeaderRow()
        // Saldo

        Saldo()

        // Ultimos movimientos
        Row(
            modifier = Modifier
                .align(alignment = Alignment.CenterHorizontally)
        )
        { UltimosMov() }

        Image(
            painter = painterResource(id = R.drawable.banner),
            contentDescription = "Banner",
            modifier = Modifier
                .padding(50.dp)
        )


        MindicatorTest(mindicatorsViewModel)

        Spacer(modifier = Modifier.weight(1f))

        // Bottom Bar
        Box(
            modifier = Modifier
                .align(alignment = Alignment.Start)
                .padding(bottom = 16.dp)

        )
        { BottomBar(navController,
            onHomeClick = { navController.navigate(Pantalla.PantallaPrincipal.route)},
            onProductosClick = {navController.navigate(Pantalla.MisProductos.route)})
        }

    }
}


