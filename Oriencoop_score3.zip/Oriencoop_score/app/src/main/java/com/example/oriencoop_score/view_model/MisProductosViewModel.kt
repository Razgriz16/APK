package com.example.oriencoop_score.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oriencoop_score.model.MisProductosResponse
import com.example.oriencoop_score.repository.MisProductosRepository
import kotlinx.coroutines.launch
import com.example.oriencoop_score.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MisProductosViewModel(
    private val token: String,
    private val rut: String
    ) : ViewModel()
    {
    // Estado inicial para los productos
    private val _productos = MutableStateFlow<MisProductosResponse?>(null)
    val productos: StateFlow<MisProductosResponse?> = _productos

    // Estado de error
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // Estado de carga
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    // Instancia del repositorio
    private val repository = MisProductosRepository()

        init {
        obtenerProductos(token, rut)
    }

    fun obtenerProductos(token: String, rut: String) {
        viewModelScope.launch {
            _isLoading.value = true // Indicar que se está cargando
            when (val result = repository.getProductos(token, rut)) {
                is Result.Success -> {
                    _productos.value = result.data // Actualizar los productos
                    _error.value = null // Limpiar errores previos
                }
                is Result.Error -> {
                    _error.value = result.exception.message // Guardar el mensaje de error
                    _productos.value = null // Limpiar los productos en caso de error
                }

                Result.Loading -> Result.Loading
            }
            _isLoading.value = false // Finalizar la carga
        }

    }
}