package com.example.oriencoop_score

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.oriencoop_score.view_model.MisProductosViewModel

class MisProductosViewModelFactory(
    private val token: String,
    private val rut: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MisProductosViewModel::class.java)) {
            return MisProductosViewModel(token, rut) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}