package com.example.oriencoop_score.view_model

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oriencoop_score.model.FacturasLcc
import com.example.oriencoop_score.model.MovimientosLcc
import com.example.oriencoop_score.repository.FacturasLccRepository
import com.example.oriencoop_score.repository.MovimientosLccRepository
import com.example.oriencoop_score.utility.Result
import com.example.oriencoop_score.utility.SessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FacturasLccViewModel @Inject constructor(
    private val repository: FacturasLccRepository,
    private val sessionManager: SessionManager,
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {
    // Estado inicial para los productos
    //private val _productos = MutableStateFlow<MisProductosResponse?>(null)
    //val productos: StateFlow<MisProductosResponse?> = _productos

    private val _facturaslcc = MutableStateFlow<List<FacturasLcc>>(emptyList())
    val facturaslcc: StateFlow<List<FacturasLcc>> = _facturaslcc

    // Estado de error
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // Estado de carga
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    init {
        obtenerFacturasLcc()
    }

    fun obtenerFacturasLcc() {
        val token = sessionManager.token.value
        val cuenta = savedStateHandle.get<Long>(LccViewModel.NRO_CUENTA_KEY) // Recupera NROCUENTA
        Log.d("FacturasLccViewModel", "numero cuenta:" + cuenta)
        viewModelScope.launch {
            Log.d("FacturasLccViewModel", "Llamando función obtenerFacturasLcc")
            _isLoading.value = true // Indicar que se está cargando
            when (val result = cuenta?.let { repository.getFacturasLcc(token, it) }) {
                is Result.Success -> {
                    Log.d("FacturasLccViewModel", "Llamada exitosa. BODY: "+result.data)
                    _facturaslcc.value = result.data.facturas_lcc
                    _error.value = null
                }
                is Result.Error -> {
                    Log.e("FacturasLccViewModel", "Llamada fallida. Error: ${result.exception.message}")
                    _error.value = result.exception.message // Guardar el mensaje de error
                    _facturaslcc.value = emptyList() // Limpiar los productos en caso de error
                }
                Result.Loading -> _isLoading.value=false
                null -> Log.d("FacturasLccViewModel", "Es nulo")
            }
            _isLoading.value = false // Finalizar la carga
        }
    }
}