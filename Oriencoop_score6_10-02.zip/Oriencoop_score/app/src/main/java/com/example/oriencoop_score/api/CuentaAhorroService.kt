package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.CuentaAhorroResponse
import com.example.oriencoop_score.model.RutRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface CuentaAhorroService {
    @POST("/cuenta_ahorro")
    suspend fun getAhorro(
        @Header("Authorization") token: String,
        @Body rutRequest: RutRequest
    ): Response<CuentaAhorroResponse>
}