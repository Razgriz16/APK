package com.example.oriencoop_score.view
import com.example.oriencoop_score.view_model.LoginViewModel
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.oriencoop_score.LoginState
import com.example.oriencoop_score.navigation.Pantalla
import com.example.oriencoop_score.R

@Composable
fun Login(navController: NavController, loginViewModel: LoginViewModel) {


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) { LoginScreen(navController, loginViewModel) }
}

//@Preview
@Composable
fun LoginScreen(navController: NavController, loginViewModel: LoginViewModel) {


    val coroutineScope = rememberCoroutineScope()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp)
            .imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo
        Image(painter = painterResource(id = R.drawable.logooriencoop), contentDescription = "Logo")

        Spacer(modifier = Modifier.height(5.dp))

        // Card with form
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f),

            ) {

            // Cuadro azul de iniciar sesión
            Column(
                modifier = Modifier
                    .background(color = Color(0xFF006FB6))
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Inicia sesión",
                    fontSize = 20.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                /***************************************************************/
                // Collect the login state from the ViewModel
                val loginState by loginViewModel.loginState.collectAsState()
                // State for user input
                val username by loginViewModel.username.collectAsState()
                val password by loginViewModel.password.collectAsState()


                Column(
                    modifier = Modifier
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Username TextField
                    TextField(
                        value = username,
                        onValueChange = { loginViewModel.updateUsername(it) } ,
                        label = { Text("Rut") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Password TextField
                    TextField(
                        value = password,
                        onValueChange = { loginViewModel.updatePassword(it) },
                        label = { Text("Contraseña") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Login Button
                    Button(

                        onClick = {loginViewModel.performLogin(username, password)},
                        //enabled = loginState !is LoginState.Loading && username.isNotBlank() && password.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFf49600))

                    ) {
                        Text("Log In")
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    // Display the login state
                    when (loginState) {
                        is LoginState.Loading -> CircularProgressIndicator()
                        is LoginState.Success -> navController.navigate(Pantalla.PantallaPrincipal.route)
                        is LoginState.Error -> Text(
                            text = "error",
                            color = Color.Red
                        )

                        else -> {}
                    }
                }
            }
        }
    }
}

