package com.example.oriencoop_score.view.mis_productos.cuenta_cap


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oriencoop_score.view.BottomBar
import com.example.oriencoop_score.view.mis_productos.cuenta_cap.components.Detalles
import com.example.oriencoop_score.view.mis_productos.cuenta_cap.components.MovimientoItem
import com.example.oriencoop_score.view.mis_productos.cuenta_cap.components.MovimientosList
import com.example.oriencoop_score.view_model.CuentaCapViewModel
import com.example.oriencoop_score.view_model.MovimientosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CuentaCap(navController: NavController, onBackClick: () -> Unit, cuentaCapViewModel: CuentaCapViewModel, movimientosViewModel: MovimientosViewModel) {
    val cuentaCapData by cuentaCapViewModel.cuentaCapData.observeAsState()
    val movimientos by movimientosViewModel.movimientos.collectAsState()
    val isLoading by movimientosViewModel.isLoading.collectAsState()
    val error by movimientosViewModel.error.collectAsState()


    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Cuenta capitalización",
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = com.example.oriencoop_score.ui.theme.amarillo
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .padding(bottom = 16.dp)

            )
            { BottomBar(navController) }
        }

    ) { paddingValues ->
        Column(
            modifier = Modifier
                .background(Color.White)
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
            //.verticalScroll(rememberScrollState())

        ) {
            Detalles(
                accountNumber = "${cuentaCapData?.NROCUENTA}",
                balance = "$ ${cuentaCapData?.SALDOCONTABLE}",
                openingDate = "${cuentaCapData?.FECHAAPERTURA}",
                accountType = "${cuentaCapData?.TIPOCUENTA}"
            )

            Spacer(modifier = Modifier.height(24.dp))
            Column(modifier = Modifier.fillMaxSize()) {
                // Title (You might want this in a separate composable)
                Text(
                    text = "Últimos Movimientos",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )

                // Display loading, error, or the list
                //when {
                //    isLoading -> {
                //        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                //            CircularProgressIndicator()
                //        }
                //    }
                //    error != null -> {
                //        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                //            Text(text = "Error: $error", color = Color.Red)
                //        }
                //    }
                //    else -> {

                MovimientosList(movimientos = movimientos)
                Spacer(modifier = Modifier.height(16.dp))

                Icon(
                    imageVector = Icons.Filled.ArrowDropDown, // Replace with your PNG
                    contentDescription = "Dropdown",
                    tint = Color.Gray
                )
            }
        }
    }
}

