package com.example.oriencoop_score.view_model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oriencoop_score.Result
import com.example.oriencoop_score.SessionManager
import com.example.oriencoop_score.model.CuentaAhorroResponse
import com.example.oriencoop_score.repository.CuentaAhorroRepository
import kotlinx.coroutines.launch

class CuentaAhorroViewModel : ViewModel() {
    val repository = CuentaAhorroRepository()

    private val _cuentaAhorroData = MutableLiveData<CuentaAhorroResponse?>() // Usamos CuentaCap?, no CuentaCapResponse
    val cuentaAhorroData: LiveData<CuentaAhorroResponse?> = _cuentaAhorroData

    // Estado de error
    private val _error = MutableLiveData<String?>() // Usamos String?, no String("")
    val error: LiveData<String?> = _error


    // Estado de carga
    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading


    init {
        cuentaAhorroDatos()
    }

    fun cuentaAhorroDatos() {
        val token = SessionManager.token.value ?: "" //Maneja los posibles null
        val rut = SessionManager.username.value ?: "" //Maneja los posibles null
        if (token.isBlank() || rut.isBlank()){ //Comprueba si son blancos
            Log.e("CuentaAhorroViewModel", "Token o Rut no pueden estar vacíos")
            _error.value = "Token o Rut no pueden estar vacíos"
            return
        }
        viewModelScope.launch {
            Log.d("CuentaAhorroViewModel", "Llamando función cuentaAhorroDatos")
            _isLoading.value = true // Indicar que se está cargando
            when (val result = repository.getAhorro(token, rut)) {
                is Result.Success -> {
                    Log.d("CuentaAhorroViewModel", "Llamada exitosa. BODY: "+result.data)
                    _cuentaAhorroData.value = result.data
                }
                is Result.Error -> {
                    Log.e("CuentaAhorroViewModel", "Llamada fallida. Error: ${result.exception.message}")
                    _error.value = result.exception.message // Guardar el mensaje de error
                }
                Result.Loading -> Result.Loading
            }
            _isLoading.value = false // Finalizar la carga
        }
    }
}