package com.example.oriencoop_score.model

data class CuentaAhorro(
    val CUENTA: Long,
    val FECHAPAGO: String,
    val MONTO: String,
    val NOMBREABRTRANSACCION: String,
    val NOMBRETRANSACCION: String,
    val ESCARGO: String
)

data class CuentaAhorroResponse(
    val movimientos: List<Movimiento>
)