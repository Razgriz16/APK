package com.example.oriencoop_score.view.mis_productos.cuenta_cap.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.oriencoop_score.R
import com.example.oriencoop_score.model.Movimiento
import com.example.oriencoop_score.model.MovimientosResponse
import com.example.oriencoop_score.ui.theme.AppTheme
@Composable
fun MovimientosList(movimientos: List<Movimiento>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp) // Space between items
    ) {
        items(movimientos) { movimiento ->
            MovimientoItem(movimiento = movimiento)
        }
    }
}

@Composable
fun MovimientoItem(movimiento: Movimiento) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = movimiento.NOMBREABRTRANSACCION,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Fecha: ${movimiento.FECHAPAGO}", style = MaterialTheme.typography.bodyMedium)
            Text(
                text = if (movimiento.ESCARGO == "N") "+$${movimiento.MONTO}" else "-$${(movimiento.MONTO)}",
                style = MaterialTheme.typography.bodyLarge,
                color = if (movimiento.ESCARGO == "N") AppTheme.colors.verde else AppTheme.colors.rojo,
                textAlign = TextAlign.Right
            )

        }
    }
}












/*
@Composable
fun Movimientos(
    description: String,
    date: String,
    amount: String,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {

        Row (verticalAlignment = Alignment.CenterVertically) {
            Text(text = description,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(text = date,
                color = Color.Gray)
        }


        Row(verticalAlignment = Alignment.CenterVertically){
            Text(
                text = amount,
                color = if(isPositive) Color.Green else Color.Red
            )

            Icon(
                painter = painterResource(id = R.drawable.pathplus),
                contentDescription = "more",
                tint = Color.Gray
            )
        }
    }
}
*/
